package Github_API_Automation;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

public class API_Test_Cases {
	
	Github_API_FunctionLibrary api = new Github_API_FunctionLibrary();
	
	//Below are variables, Please change only Repository_name variable to create with new name
    //Token related variables are depend on the user if you want to change user please change both token related variables
    String Github_creare_api = "https://api.github.com/user/repos";
    String Github_delete_api = "https://api.github.com/repos/jayldec/";   //here jayldec is user name
    String token_id_create = "868dc4804f5b707f6cff81b3c3cfd211fae3d6ba";
    String token_id_delete = "e7c4024b9ca011764ffad03caa2ece95bf11ac51";
    String Repository_name = "Jay_python_29102016";
    
   // @Test
    public void Test_case_1() throws JSONException{
    	String Test_case_1_repo = api.Github_create_repo(Github_creare_api, token_id_create, Repository_name);
    	System.out.println("Response:-- "+Test_case_1_repo);
        JSONObject jObject = new JSONObject(Test_case_1_repo);
        
        try {
        	System.out.println(jObject.getString("name"));
        	if(jObject.getString("name").equals(Repository_name)){
        		System.out.println("Test Case 1 is PASS :- Test case Name Create Repository with Github API");
        		System.out.println("Repository is created");
        		System.out.println("Repository name is :- " + Repository_name);
        	}
        	else
        	{
        		System.out.println("Test Case 1 is FAIL :- Test case name Create Repository with Github API");
        		System.out.println("Repository is not created");
        	}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			System.out.println("Test_case_1_repo");
			System.out.println("Hey User either your Repository is already there if you can see Validation failed message or You are not creating repository correctly");
		}
    }
    
    @Test
    public void Test_case_2() throws JSONException{
    	int Test_case_2_repo = api.Github_delete_repo(Github_delete_api, token_id_delete, Repository_name);
    	System.out.println("Response:-- "+Test_case_2_repo);
        
        try {
        	if (Test_case_2_repo == 204){
                System.out.println("Test Case 2 is PASS :- Test case Name Delete Repository with Github API");
                System.out.println("Repository is deleted"); 
                System.out.println("Repository name is :- "+Repository_name);
        	}else{
        		System.out.println("Test Case 2 is FAIL :- Test case Name Delete Repository with Github API");
        		System.out.println("Repository deletion Failed"); 
        		System.out.println("Repository name is :- "+Repository_name);  
        		System.out.println("Hey User either your Repository is not created or You are not authorised owner to delete repository");
        	}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			System.out.println("Test_case_1_repo");
			System.out.println("Hey User either your Repository is already there if you can see Validation failed message or You are not creating repository correctly");
		}
    }
    
}
   	
    	
