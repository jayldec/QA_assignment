package Github_API_Automation;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class Github_API_FunctionLibrary {
	
	public String Github_create_repo(String api_details,String token_Id,String repo_name){
		String json = null;
		try{
	        String API1 = api_details;
	        System.out.println(API1);
	        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	        HttpPost request = new HttpPost(API1);
	        String Body = "{\"name\":\""+repo_name+"\",\"description\":\"This is your first repository\",\"homepage\": \"https://github.com\"}";
	        System.out.println(Body);	        
	        StringEntity params = new StringEntity(Body);
	        System.out.println("Body--> "+Body);
//	        request.addHeader("content-type", "application/json");
	        request.addHeader("Authorization", "token "+token_Id);
	        request.setEntity(params);
	        HttpResponse result = httpClient.execute(request);
	        json = EntityUtils.toString(result.getEntity(), "UTF-8");
	        System.out.println(json);
	        
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return json;
	}
	
	public int Github_delete_repo(String api_details,String token_Id,String repo_name){
		int result_status = 0;
		try{
	        String API1 = api_details+repo_name;
	        System.out.println(API1);
	        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	        HttpDelete request = new HttpDelete(API1);
	        request.addHeader("content-type", "application/json");
	        request.addHeader("Authorization", "token "+token_Id);
	        HttpResponse result = httpClient.execute(request);
	        System.out.println(result.getStatusLine());
	        result_status = result.getStatusLine().getStatusCode();
	        
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return result_status;
	}
	

}


