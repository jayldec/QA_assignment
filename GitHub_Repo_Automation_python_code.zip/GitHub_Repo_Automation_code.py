import csv
import time
import requests
from requests import request
import json
import threading
from Queue import Queue
import traceback
from collections import Counter
import logging
import os
import base64

logging.basicConfig(filename='Report.log',format='%(levelname)s %(asctime)s :: %(message)s',level=logging.DEBUG)



# Create Github Repository with help of API
def Github_create_repo(api_details,token_Id,repo_name):
    try:
        API1 = api_details
        print API1
        headers1 = {"content-type": "application/json","Authorization": "token "+str(token_Id).strip()+""}
#        print headers1
        Body = {"name":repo_name,"description":"This is your first repository","homepage": "https://github.com"}
#        print Body
        a=json.dumps(Body)
#        print a
        resp1 = requests.post(API1,a,headers=headers1, cookies=None )
        Resp_text = resp1.text
        api_resp = json.loads(Resp_text)
#        print api_resp
#        print resp1.status_code
#        print resp1.reason
    except Exception, error:
            print "Error : " + str(error)
    return api_resp

# Delete Github Repository with help of API
def Github_delete_repo(api_details,token_Id,repo_name):
    try:
        API1 = api_details+repo_name
        print API1
        headers1 = {"Authorization": "token "+str(token_Id).strip()+""}
        b=json.dumps(headers1)
        print b
        resp1 = requests.delete(API1,headers=headers1)
#        print resp1.status_code
        res=resp1.status_code
#        print resp1.reason
    except Exception, error:
            print "Error : " + str(error)
    return res

# Main Function For Test Cases
if __name__=="__main__":
    #Below are variables, Please change only Repository_name variable to create with new name
    #Token related variables are depend on the user if you want to change user please change both token related variables
    Github_creare_api = "https://api.github.com/user/repos"
    Github_delete_api = "https://api.github.com/repos/jayldec/"   #here jayldec is user name
    token_id_create = "868dc4804f5b707f6cff81b3c3cfd211fae3d6ba"
    token_id_delete = "e7c4024b9ca011764ffad03caa2ece95bf11ac51"
    Repository_name = "Jay_python_29102016"

    def Test_case_1():
        Test_case_1_repo = Github_create_repo(Github_creare_api,token_id_create,Repository_name)
        try:
            print Test_case_1_repo['name']
            if Test_case_1_repo['name']== Repository_name:
                print "Test Case 1 is PASS :- Test case Name Create Repository with Github API"
                print "Repository is created"
                print "Repository name is :- %s"%Repository_name
            else:
                print "Test Case 1 is FAIL :- Test case Name Create Repository with Github API"
                print "Repository is not created"
        except:
            print Test_case_1_repo
            print "Hey User either your Repository is already there if you can see Validation failed message or You are not creating repository correctly"

    def Test_case_2():
        Test_case_2_repo = Github_delete_repo(Github_delete_api,token_id_delete,Repository_name)
        try:
            if Test_case_2_repo == 204:
                print "Test Case 2 is PASS :- Test case Name Delete Repository with Github API"
                print "Repository is deleted"
                print "Repository name is :- %s"%Repository_name
            else:
                print "Test Case 2 is FAIL :- Test case Name Delete Repository with Github API"
                print "Repository deletion Failed"
                print "Repository name is :- %s"%Repository_name
                print "Hey User either your Repository is not created or You are not authorised owner to delete repository"

        except Exception, error:
            print "Error : " + str(error)

# You can run both test case and you can run individual test case by commenting any one
    Test_case_1()   #Test case 1 for varify create repository
    Test_case_2()   #Test case 2 for varify delete repository














